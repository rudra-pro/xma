<?php
if (!defined('ABSPATH')) exit;

// --- WooCommerce Order Status Change Hook ---
if (class_exists('WooCommerce')) {
    add_action('woocommerce_order_status_changed', function($order_id, $from_status, $to_status, $order) {
        // Get order object
        if (!$order) $order = wc_get_order($order_id);
        if (!$order) return;

        // Get customer info
        $customer_phone = $order->get_billing_phone();
        $customer_name = $order->get_billing_first_name() . ' ' . $order->get_billing_last_name();
        $order_total = $order->get_total();
        $order_items = [];
        foreach ($order->get_items() as $item) {
            $order_items[] = $item->get_name();
        }
        $category_names = [];
        foreach ($order->get_items() as $item) {
            $product = $item->get_product();
            if ($product) {
                $cats = wp_get_post_terms($product->get_id(), 'product_cat', ['fields' => 'names']);
                $category_names = array_merge($category_names, $cats);
            }
        }
        $category_names = array_unique($category_names);

        // Fetch template for this category/status
        $template_res = xma_api_request('/templates', [
            'type' => 'woocommerce',
            'category' => $category_names ? $category_names[0] : 'default',
            'status' => $to_status,
        ], 'GET');
        $template = ($template_res['success'] && !empty($template_res['data']['template'])) ? $template_res['data']['template'] : '';
        if (!$template) return;

        // Fill variables
        $variables = [
            '{customer_name}' => $customer_name,
            '{order_id}' => $order_id,
            '{order_total}' => $order_total,
            '{order_items}' => implode(', ', $order_items),
            '{order_status}' => $to_status,
            '{category}' => $category_names ? $category_names[0] : '',
            '{site_name}' => get_bloginfo('name'),
        ];
        $message = strtr($template, $variables);

        // Send WhatsApp message via XMA API
        $send_res = xma_api_request('/send', [
            'recipient' => $customer_phone,
            'message' => $message,
            'event' => 'woocommerce',
            'order_id' => $order_id,
            'status' => $to_status,
        ]);

        // Log result
        do_action('xma_log_event', [
            'type' => 'woocommerce',
            'event' => $to_status,
            'recipient' => $customer_phone,
            'data' => [
                'order_id' => $order_id,
                'customer_name' => $customer_name,
                'order_total' => $order_total,
                'order_items' => $order_items,
                'category' => $category_names,
            ],
            'template' => $template,
            'message' => $message,
            'response' => $send_res,
            'success' => $send_res['success'],
            'timestamp' => current_time('mysql'),
        ]);
    }, 10, 4);
}

// --- Supported Forms Integration ---
// Helper: Register a generic form event handler
function xma_handle_form_submission($form_name, $fields, $raw_data = []) {
    // Try to fetch template for this form
    $template_res = xma_api_request('/templates', [
        'type' => 'form',
        'form' => $form_name,
    ], 'GET');
    $template = ($template_res['success'] && !empty($template_res['data']['template'])) ? $template_res['data']['template'] : '';
    if (!$template) return;

    // Build variables array
    $variables = [
        '{site_name}' => get_bloginfo('name'),
    ];
    foreach ($fields as $key => $value) {
        $variables['{' . $key . '}'] = $value;
    }
    $message = strtr($template, $variables);

    // Try to find a phone field
    $recipient = '';
    foreach ($fields as $key => $value) {
        if (stripos($key, 'phone') !== false) {
            $recipient = $value;
            break;
        }
    }
    if (!$recipient) return;

    // Send WhatsApp message via XMA API
    $send_res = xma_api_request('/send', [
        'recipient' => $recipient,
        'message' => $message,
        'event' => 'form',
        'form' => $form_name,
        'fields' => $fields,
    ]);

    // Log result
    do_action('xma_log_event', [
        'type' => 'form',
        'event' => $form_name,
        'recipient' => $recipient,
        'data' => $fields,
        'template' => $template,
        'message' => $message,
        'response' => $send_res,
        'success' => $send_res['success'],
        'timestamp' => current_time('mysql'),
    ]);
}

// Elementor Forms
add_action('elementor_pro/forms/new_record', function($record, $handler) {
    $fields = [];
    foreach ($record->get('fields') as $field) {
        $fields[$field['name']] = $field['value'];
    }
    xma_handle_form_submission('Elementor', $fields);
}, 10, 2);

// Forminator
add_action('forminator_form_after_handle', function($form_id, $response, $form_fields, $entry, $form_settings) {
    $fields = [];
    foreach ($form_fields as $field) {
        $fields[$field['name']] = $field['value'];
    }
    xma_handle_form_submission('Forminator', $fields);
}, 10, 5);

// Fluent Forms
add_action('fluentform_submission_inserted', function($entryId, $formData, $form) {
    xma_handle_form_submission('FluentForms', $formData);
}, 10, 3);

// Contact Form 7
add_action('wpcf7_mail_sent', function($contact_form) {
    $submission = WPCF7_Submission::get_instance();
    if ($submission) {
        $fields = $submission->get_posted_data();
        xma_handle_form_submission('ContactForm7', $fields);
    }
});

// Gravity Forms
add_action('gform_after_submission', function($entry, $form) {
    $fields = [];
    foreach ($form['fields'] as $field) {
        if (isset($entry[$field->id])) {
            $fields[$field->label] = $entry[$field->id];
        }
    }
    xma_handle_form_submission('GravityForms', $fields);
}, 10, 2);

// WPForms
add_action('wpforms_process_complete', function($fields, $entry, $form_data, $entry_id) {
    $data = [];
    foreach ($fields as $field) {
        $data[$field['name']] = $field['value'];
    }
    xma_handle_form_submission('WPForms', $data);
}, 10, 4);

// --- Logging Event (for logs.php) ---
// This action is used by logs.php to store logs in DB or options.
// do_action('xma_log_event', $log_array); 