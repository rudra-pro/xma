<?php
if (!defined('ABSPATH')) exit;

// Option key for storing templates
const XMA_OPTION_TEMPLATES = 'xma_templates';

// Helper: Get all templates
function xma_get_templates() {
    return get_option(XMA_OPTION_TEMPLATES, []);
}

// Helper: Save all templates
function xma_save_templates($templates) {
    update_option(XMA_OPTION_TEMPLATES, $templates);
}

// Helper: Get template by key
function xma_get_template($type, $key, $status = '', $lang = 'default') {
    $templates = xma_get_templates();
    if (isset($templates[$type][$key][$status][$lang])) {
        return $templates[$type][$key][$status][$lang];
    }
    // Fallbacks
    if (isset($templates[$type][$key]['default'][$lang])) {
        return $templates[$type][$key]['default'][$lang];
    }
    if (isset($templates[$type]['default']['default'][$lang])) {
        return $templates[$type]['default']['default'][$lang];
    }
    return '';
}

// Helper: Save template (with versioning)
function xma_save_template($type, $key, $status, $lang, $content) {
    $templates = xma_get_templates();
    // Versioning: keep last 5 versions
    $history = $templates[$type][$key][$status][$lang]['history'] ?? [];
    $current = $templates[$type][$key][$status][$lang]['content'] ?? '';
    if ($current && $current !== $content) {
        array_unshift($history, [
            'content' => $current,
            'timestamp' => current_time('mysql'),
        ]);
        $history = array_slice($history, 0, 5);
    }
    $templates[$type][$key][$status][$lang] = [
        'content' => $content,
        'history' => $history,
        'updated' => current_time('mysql'),
    ];
    xma_save_templates($templates);
}

// Helper: Rollback template
function xma_rollback_template($type, $key, $status, $lang, $version = 0) {
    $templates = xma_get_templates();
    $history = $templates[$type][$key][$status][$lang]['history'] ?? [];
    if (isset($history[$version])) {
        $templates[$type][$key][$status][$lang]['content'] = $history[$version]['content'];
        // Remove this version from history
        array_splice($templates[$type][$key][$status][$lang]['history'], $version, 1);
        xma_save_templates($templates);
        return true;
    }
    return false;
}

// REST: Templates CRUD
add_action('rest_api_init', function() {
    // List templates
    register_rest_route('xma/v1', '/local-templates', [
        'methods' => 'GET',
        'permission_callback' => 'is_user_logged_in',
        'callback' => function($request) {
            return xma_get_templates();
        }
    ]);
    // Get single template
    register_rest_route('xma/v1', '/local-templates/get', [
        'methods' => 'GET',
        'permission_callback' => 'is_user_logged_in',
        'callback' => function($request) {
            $type = sanitize_text_field($request['type']);
            $key = sanitize_text_field($request['key']);
            $status = sanitize_text_field($request['status'] ?? 'default');
            $lang = sanitize_text_field($request['lang'] ?? 'default');
            return xma_get_template($type, $key, $status, $lang);
        }
    ]);
    // Save template
    register_rest_route('xma/v1', '/local-templates/save', [
        'methods' => 'POST',
        'permission_callback' => 'is_user_logged_in',
        'callback' => function($request) {
            $params = $request->get_json_params();
            $type = sanitize_text_field($params['type']);
            $key = sanitize_text_field($params['key']);
            $status = sanitize_text_field($params['status'] ?? 'default');
            $lang = sanitize_text_field($params['lang'] ?? 'default');
            $content = $params['content'] ?? '';
            xma_save_template($type, $key, $status, $lang, $content);
            return ['success' => true];
        }
    ]);
    // Delete template
    register_rest_route('xma/v1', '/local-templates/delete', [
        'methods' => 'POST',
        'permission_callback' => 'is_user_logged_in',
        'callback' => function($request) {
            $params = $request->get_json_params();
            $type = sanitize_text_field($params['type']);
            $key = sanitize_text_field($params['key']);
            $status = sanitize_text_field($params['status'] ?? 'default');
            $lang = sanitize_text_field($params['lang'] ?? 'default');
            $templates = xma_get_templates();
            unset($templates[$type][$key][$status][$lang]);
            xma_save_templates($templates);
            return ['success' => true];
        }
    ]);
    // Rollback template
    register_rest_route('xma/v1', '/local-templates/rollback', [
        'methods' => 'POST',
        'permission_callback' => 'is_user_logged_in',
        'callback' => function($request) {
            $params = $request->get_json_params();
            $type = sanitize_text_field($params['type']);
            $key = sanitize_text_field($params['key']);
            $status = sanitize_text_field($params['status'] ?? 'default');
            $lang = sanitize_text_field($params['lang'] ?? 'default');
            $version = intval($params['version'] ?? 0);
            $ok = xma_rollback_template($type, $key, $status, $lang, $version);
            return ['success' => $ok];
        }
    ]);
}); 