<?php
if (!defined('ABSPATH')) exit;

// Option key for storing XMA API token
const XMA_OPTION_TOKEN = 'xma_api_token';
const XMA_OPTION_USER = 'xma_api_user';
const XMA_API_BASE = 'https://x.whatsappbulk.co.in/api';

// Helper: Get stored token
function xma_get_token() {
    return get_option(XMA_OPTION_TOKEN, '');
}

// Helper: Set token
function xma_set_token($token) {
    update_option(XMA_OPTION_TOKEN, $token);
}

// Helper: Remove token
function xma_remove_token() {
    delete_option(XMA_OPTION_TOKEN);
    delete_option(XMA_OPTION_USER);
}

// Helper: Get user info
function xma_get_user() {
    return get_option(XMA_OPTION_USER, []);
}

// Helper: Set user info
function xma_set_user($user) {
    update_option(XMA_OPTION_USER, $user);
}

// Helper: Make API request
function xma_api_request($endpoint, $body = [], $method = 'POST', $auth = true) {
    $headers = [
        'Content-Type' => 'application/json',
    ];
    if ($auth && xma_get_token()) {
        $headers['Authorization'] = 'Bearer ' . xma_get_token();
    }
    $args = [
        'headers' => $headers,
        'timeout' => 20,
    ];
    if ($method === 'POST') {
        $args['body'] = json_encode($body);
        $response = wp_remote_post(XMA_API_BASE . $endpoint, $args);
    } else {
        if (!empty($body)) {
            $endpoint .= '?' . http_build_query($body);
        }
        $response = wp_remote_get(XMA_API_BASE . $endpoint, $args);
    }
    if (is_wp_error($response)) {
        return ['success' => false, 'error' => $response->get_error_message()];
    }
    $data = json_decode(wp_remote_retrieve_body($response), true);
    if (isset($data['error'])) {
        return ['success' => false, 'error' => $data['error']];
    }
    return ['success' => true, 'data' => $data];
}

// REST: Login
add_action('rest_api_init', function() {
    // LOGIN ENDPOINT
    register_rest_route('xma/v1', '/login', [
        'methods' => 'POST',
        'callback' => 'xma_api_login',
        'permission_callback' => '__return_true', // Restrict in production!
    ]);

    // REST: Logout
    register_rest_route('xma/v1', '/logout', [
        'methods' => 'POST',
        'permission_callback' => function() { return (bool)xma_get_token(); },
        'callback' => function() {
            xma_remove_token();
            return [ 'success' => true ];
        }
    ]);

    // REST: Status (plan, credits, device)
    register_rest_route('xma/v1', '/status', [
        'methods' => 'GET',
        'permission_callback' => function() { return (bool)xma_get_token(); },
        'callback' => function() {
            $res = xma_api_request('/status', [], 'GET');
            if ($res['success']) return $res['data'];
            return new WP_Error('xma_status_failed', $res['error'] ?? 'Status failed', ['status' => 400]);
        }
    ]);

    // REST: Device (connect, disconnect, QR, etc)
    register_rest_route('xma/v1', '/device', [
        'methods' => 'GET',
        'permission_callback' => function() { return (bool)xma_get_token(); },
        'callback' => function() {
            $res = xma_api_request('/device', [], 'GET');
            if ($res['success']) return $res['data'];
            return new WP_Error('xma_device_failed', $res['error'] ?? 'Device failed', ['status' => 400]);
        }
    ]);
    register_rest_route('xma/v1', '/device/connect', [
        'methods' => 'POST',
        'permission_callback' => function() { return (bool)xma_get_token(); },
        'callback' => function($request) {
            $res = xma_api_request('/device/connect', $request->get_json_params(), 'POST');
            if ($res['success']) return $res['data'];
            return new WP_Error('xma_device_connect_failed', $res['error'] ?? 'Device connect failed', ['status' => 400]);
        }
    ]);
    register_rest_route('xma/v1', '/device/disconnect', [
        'methods' => 'POST',
        'permission_callback' => function() { return (bool)xma_get_token(); },
        'callback' => function($request) {
            $res = xma_api_request('/device/disconnect', $request->get_json_params(), 'POST');
            if ($res['success']) return $res['data'];
            return new WP_Error('xma_device_disconnect_failed', $res['error'] ?? 'Device disconnect failed', ['status' => 400]);
        }
    ]);

    // REST: Templates
    register_rest_route('xma/v1', '/templates', [
        'methods' => 'GET',
        'permission_callback' => function() { return (bool)xma_get_token(); },
        'callback' => function() {
            $res = xma_api_request('/templates', [], 'GET');
            if ($res['success']) return $res['data'];
            return new WP_Error('xma_templates_failed', $res['error'] ?? 'Templates failed', ['status' => 400]);
        }
    ]);
    register_rest_route('xma/v1', '/templates', [
        'methods' => 'POST',
        'permission_callback' => function() { return (bool)xma_get_token(); },
        'callback' => function($request) {
            $res = xma_api_request('/templates', $request->get_json_params(), 'POST');
            if ($res['success']) return $res['data'];
            return new WP_Error('xma_templates_save_failed', $res['error'] ?? 'Templates save failed', ['status' => 400]);
        }
    ]);

    // REST: Logs
    register_rest_route('xma/v1', '/logs', [
        'methods' => 'GET',
        'permission_callback' => function() { return (bool)xma_get_token(); },
        'callback' => function($request) {
            $params = $request->get_params();
            $res = xma_api_request('/logs', $params, 'GET');
            if ($res['success']) return $res['data'];
            return new WP_Error('xma_logs_failed', $res['error'] ?? 'Logs failed', ['status' => 400]);
        }
    ]);

    // REST: Send WhatsApp (test-send, resend, etc)
    register_rest_route('xma/v1', '/send', [
        'methods' => 'POST',
        'permission_callback' => function() { return (bool)xma_get_token(); },
        'callback' => function($request) {
            $res = xma_api_request('/send', $request->get_json_params(), 'POST');
            if ($res['success']) return $res['data'];
            return new WP_Error('xma_send_failed', $res['error'] ?? 'Send failed', ['status' => 400]);
        }
    ]);
});

// --- Login Callback: Calls Zender SaaS API ---
function xma_api_login($request) {
    $params = $request->get_json_params();
    $email = $params['email'] ?? '';
    $password = $params['password'] ?? '';
    $remember = $params['remember'] ?? false;
    if (!$email || !$password) {
        return [ 'success' => false, 'message' => 'Email and password required.' ];
    }
    $response = wp_remote_post(XMA_API_BASE . '/login', [
        'body' => [
            'email' => $email,
            'password' => $password,
            'remember' => $remember ? '1' : '0',
        ],
        'timeout' => 15,
    ]);
    if (is_wp_error($response)) {
        return [ 'success' => false, 'message' => 'Could not connect to API.' ];
    }
    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);
    if (!empty($data['token'])) {
        xma_set_token($data['token']);
        xma_set_user($data['user'] ?? []);
        return [
            'success' => true,
            'user' => $data['user'] ?? [],
            'token' => $data['token'],
        ];
    }
    return [
        'success' => false,
        'message' => $data['message'] ?? 'Login failed',
    ];
} 