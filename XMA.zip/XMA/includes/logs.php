<?php
if (!defined('ABSPATH')) exit;

// Option key for storing logs
const XMA_OPTION_LOGS = 'xma_logs';
const XMA_LOGS_MAX = 1000;

// Helper: Get all logs
function xma_get_logs() {
    return get_option(XMA_OPTION_LOGS, []);
}

// Helper: Save all logs
function xma_save_logs($logs) {
    update_option(XMA_OPTION_LOGS, $logs);
}

// Helper: Add a log entry
function xma_add_log($log) {
    $logs = xma_get_logs();
    array_unshift($logs, $log); // newest first
    $logs = array_slice($logs, 0, XMA_LOGS_MAX);
    xma_save_logs($logs);
}

// Listen to xma_log_event action
add_action('xma_log_event', function($log) {
    xma_add_log($log);
});

// REST: Logs endpoints
add_action('rest_api_init', function() {
    // Fetch logs (with filters)
    register_rest_route('xma/v1', '/logs-local', [
        'methods' => 'GET',
        'permission_callback' => 'is_user_logged_in',
        'callback' => function($request) {
            $logs = xma_get_logs();
            $params = $request->get_params();
            // Filtering
            if (!empty($params['type'])) {
                $logs = array_filter($logs, function($log) use ($params) {
                    return $log['type'] === $params['type'];
                });
            }
            if (!empty($params['event'])) {
                $logs = array_filter($logs, function($log) use ($params) {
                    return $log['event'] === $params['event'];
                });
            }
            if (!empty($params['recipient'])) {
                $logs = array_filter($logs, function($log) use ($params) {
                    return strpos($log['recipient'], $params['recipient']) !== false;
                });
            }
            if (!empty($params['status'])) {
                $logs = array_filter($logs, function($log) use ($params) {
                    return ($params['status'] === 'success') ? $log['success'] : !$log['success'];
                });
            }
            if (!empty($params['date_from']) || !empty($params['date_to'])) {
                $from = !empty($params['date_from']) ? strtotime($params['date_from']) : 0;
                $to = !empty($params['date_to']) ? strtotime($params['date_to']) : time();
                $logs = array_filter($logs, function($log) use ($from, $to) {
                    $ts = strtotime($log['timestamp']);
                    return $ts >= $from && $ts <= $to;
                });
            }
            return array_values($logs);
        }
    ]);
    // View log details
    register_rest_route('xma/v1', '/logs-local/detail', [
        'methods' => 'GET',
        'permission_callback' => 'is_user_logged_in',
        'callback' => function($request) {
            $logs = xma_get_logs();
            $id = intval($request['id']);
            return isset($logs[$id]) ? $logs[$id] : null;
        }
    ]);
    // Resend message
    register_rest_route('xma/v1', '/logs-local/resend', [
        'methods' => 'POST',
        'permission_callback' => 'is_user_logged_in',
        'callback' => function($request) {
            $params = $request->get_json_params();
            $logs = xma_get_logs();
            $id = intval($params['id']);
            if (!isset($logs[$id])) return new WP_Error('not_found', 'Log not found', ['status' => 404]);
            $log = $logs[$id];
            // Resend via XMA API
            $send_res = xma_api_request('/send', [
                'recipient' => $log['recipient'],
                'message' => $log['message'],
                'event' => $log['type'],
                'fields' => $log['data'],
            ]);
            // Log the resend
            xma_add_log([
                'type' => $log['type'],
                'event' => $log['event'],
                'recipient' => $log['recipient'],
                'data' => $log['data'],
                'template' => $log['template'],
                'message' => $log['message'],
                'response' => $send_res,
                'success' => $send_res['success'],
                'timestamp' => current_time('mysql'),
                'resend_of' => $id,
            ]);
            return $send_res;
        }
    ]);
}); 