<?php
/*
Plugin Name: XMA WhatsApp Automation
Description: Modern WhatsApp automation for WooCommerce, forms, and more. 2025-level UI/UX.
Version: 1.0.0
Author: XMA Team
*/

if (!defined('ABSPATH')) exit;

define('XMA_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('XMA_PLUGIN_URL', plugin_dir_url(__FILE__));
define('XMA_PLUGIN_VERSION', '1.0.0');

// --- Admin Menu: XMA WhatsApp ---
add_action('admin_menu', function() {
    add_menu_page(
        'XMA WhatsApp',
        'XMA WhatsApp',
        'manage_options',
        'xma-whatsapp',
        function() {
            echo '<div id="xma-admin-root"></div>';
        },
        XMA_PLUGIN_URL . 'assets/xma-logo.png',
        26
    );
});

// --- Enqueue React SPA only on XMA page ---
add_action('admin_enqueue_scripts', function($hook) {
    if (strpos($hook, 'xma-whatsapp') === false) return;
    wp_enqueue_style('xma-admin', XMA_PLUGIN_URL . 'assets/xma-admin.css', [], XMA_PLUGIN_VERSION);
    wp_enqueue_script('xma-admin', XMA_PLUGIN_URL . 'admin/build/index.js', ['wp-element'], XMA_PLUGIN_VERSION, true);
    // Pass data to JS
    wp_localize_script('xma-admin', 'XMA_DATA', [
        'plugin_url' => XMA_PLUGIN_URL,
        'rest_url' => esc_url_raw(rest_url()),
        'nonce' => wp_create_nonce('wp_rest'),
    ]);
});

// --- Include backend modules ---
foreach ([
    'includes/api.php',
    'includes/hooks.php',
    'includes/templates.php',
    'includes/logs.php',
] as $file) {
    require_once XMA_PLUGIN_DIR . $file;
}

// --- Restrict page to logged-in users ---
add_action('admin_init', function() {
    if (isset($_GET['page']) && $_GET['page'] === 'xma-whatsapp' && !is_user_logged_in()) {
        wp_die('You must be logged in to access this page.');
    }
}); 