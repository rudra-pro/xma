XMA WhatsApp WordPress Plugin
============================

A modern WhatsApp automation plugin for WordPress, integrating with WooCommerce, forms, and more. Built for 2025-level UI/UX and automation.

Features:
---------
- XMA-branded admin dashboard (SPA, React-based)
- Secure XMA login (email/password)
- WhatsApp device management (QR connect, status, disconnect)
- API & device info cards
- WooCommerce & forms integration (Elementor, Forminator, Fluent Forms, Contact Form 7, Gravity, WPForms)
- Per-category/order status WhatsApp templates
- Per-form WhatsApp templates with field mapping
- Rich template editor (variables, preview, test-send, versioning)
- Message logs (search, filter, resend, details)
- Help/FAQ/support tab
- Responsive, animated, modern UI

Installation:
-------------
1. Upload the `XMA` folder to your `/wp-content/plugins/` directory.
2. Activate the plugin from the WordPress admin.
3. Open the XMA menu in the WP admin sidebar.
4. Login with your XMA account and connect your WhatsApp device.
5. Configure templates, integrations, and start automating!

Usage:
------
- Use the sidebar to navigate between Status, API/Device, Templates, Messages, and Help.
- Set up WooCommerce and form templates for WhatsApp automation.
- View logs and troubleshoot from the Messages and Help tabs.

Branding:
---------
- The plugin uses the XMA logo (see `/assets/xma-logo.png`).

For support, visit the Help tab or contact XMA support. 